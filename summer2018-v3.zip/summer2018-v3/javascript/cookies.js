/*
	Dominik Jedruszczak
	Benjamin Knutson
	Cookies

	Credit to W3Schools.
*/

/* Returns a cookie. */
function getCookie(name) {
	/* Split the cookies into an array. */
	var cookies = document.cookie.split(";");
	/* Search the cookies for the desired cookie and return the value. */

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		while (cookie.charAt(0)==' ') // Strip the leading whitespace.
			cookie = cookie.substring(1);
		if (cookie.indexOf(name) == 0)
			return cookie.substring(name.length + 1, cookie.length);
	}
	return "";
}

/* Sets a cookie. */
function setCookie(name, value, ttl) {
	/* If time to live is not provided, set it to the default value. */
	if (!ttl) {
		var ttl = 7*24*60*60*1000; // One week.
	}

	/* Create the expiration date. */
	var expiration = new Date();
	expiration.setTime(expiration.getTime() + ttl);
	expiration = "expires=" + expiration.toUTCString();

	/* Set the cookie. */
	document.cookie = name + "=" + value + ";" + expiration;
}
