function generateCharMenu() {
  
  var filename = "../json/characters.json";
  $.ajax({
    url : filename,
    datatype : "json",
    success : function (data) {
      var char_list = JSON.parse(data);
      console.log(char_list);
      var HTML_DIV_profiles = document.getElementById("profiles");
      for (var i = 0; i < char_list.length; i++) {
        var HTML_DIV_char = document.createElement("div");
        HTML_DIV_char.className="character";
		var test = "charSelect("+ char_list[i].name +")";
        HTML_DIV_char.setAttribute("onclick", "charSelect('"+ char_list[i].name +"', '" + char_list[i].bio +"')");
		
		
		
        var HTML_IMG_image = document.createElement("img");
        if (char_list[i].image != null) {
          HTML_IMG_image.src = char_list[i].image;
        }
        HTML_DIV_char.appendChild(HTML_IMG_image);
        
        
        var HTML_P_text = document.createElement("p");
        var HTML_P_TEXT_text = document.createTextNode(char_list[i].name);
        HTML_P_text.appendChild(HTML_P_TEXT_text);
        HTML_P_text.className="char_name";
        HTML_DIV_char.appendChild(HTML_P_text);
        
        
        var HTML_P_tagline = document.createElement("p");
        var HTML_P_TEXT_tagline = document.createTextNode(char_list[i].tagline);
        HTML_P_tagline.appendChild(HTML_P_TEXT_tagline);
        HTML_P_tagline.className="tagline";
        HTML_DIV_char.appendChild(HTML_P_tagline);
      
        
        HTML_DIV_profiles.appendChild(HTML_DIV_char);
        
      }
    },
    error : function(a, b, c) {
      console.log(a);
      console.log(b);
      console.log(c);
    }
  });
}

function charSelect(name,bio) {
  var popup=document.createElement("div");
  popup.className="popup";
  popup.id="popup";
  popup.setAttribute("onclick", "document.body.removeChild(this); \
                                 document.body.style.overflow='auto';");


  var visible=document.createElement("div");
  visible.className = "visible";
  visible.setAttribute("onclick", "console.log('safe'); \
                       if (!e) var e = window.event; \
                       e.cancelBubble = true; \
                       if (e.stopPropagation) e.stopPropagation();");
  
  var txt = document.createElement("p");
  txt.innerHTML=bio;
  txt.id = "bio";
  
  var x = document.createElement("img")
  x.setAttribute("src", "../images/x.png");
  x.setAttribute("onclick", "document.body.removeChild(document.getElementById('popup'))");
  x.id="x";
  
  var link = document.createElement("a");
  link.setAttribute("href", "other_profile.html");
  link.id = "link";
  var cont_button = document.createElement("p");
  cont_button.innerHTML = "Continue to Profile";
  cont_button.className="continue";
  cont_button.setAttribute("onclick", "setCookie('character', '" + name + "');");
  link.appendChild(cont_button);
  
  
  
  visible.appendChild(txt);
  visible.appendChild(x);
  visible.appendChild(link);
  popup.appendChild(visible);
  document.body.appendChild(popup);

    
}