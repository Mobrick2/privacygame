<?php

	/* check login status*/
	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Check Unique Id
	*/
	if ( !isset($_POST['email']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	$clientname = $_POST["username"];
	$clientpw = md5($_POST["password"]);
	$email = $_POST["email"];
	
	/* Get the user's version. */
	$sql = "INSERT INTO loginUser (name, passwd, email) VALUES ('$clientname', '$clientpw', '$email')";
	
	if (mysqli_query($connection, $sql)) {

	       // Counts posts in each character and generates answer and progress strings for all of them.
              $aidenPostCount = count(json_decode(file_get_contents("../json/posts/Aiden.json"), true));
              $aidenAnswersString = str_repeat("X", $aidenPostCount*2);
              $aidenProgressString = str_repeat("0", $aidenPostCount);

              $lucasPostCount = count(json_decode(file_get_contents("../json/posts/Lucas.json"), true));
              $lucasAnswersString = str_repeat("X", $lucasPostCount*2);
              $lucasProgressString = str_repeat("0", $lucasPostCount);

              $oliviaPostCount = count(json_decode(file_get_contents("../json/posts/Olivia.json"), true));
              $oliviaAnswersString = str_repeat("X", $oliviaPostCount*2);
              $oliviaProgressString = str_repeat("0", $oliviaPostCount);

              $sophiaPostCount = count(json_decode(file_get_contents("../json/posts/Sophia.json"), true));
              $sophiaAnswersString = str_repeat("X", $sophiaPostCount*2);
              $sophiaProgressString = str_repeat("0", $sophiaPostCount);

	      $version=0;
	      $sql = "insert into users values('" . $clientname .
                "', " . $version .
                ", '" . $aidenAnswersString . "' ,'" . $aidenProgressString .
                "', '" . $lucasAnswersString . "' ,'" . $lucasProgressString .
                "', '" . $oliviaAnswersString . "' ,'" . $oliviaProgressString .
                "', '" . $sophiaAnswersString . "' ,'" . $sophiaProgressString .
                "', 'Sophia', 0, NOW())";
              if ( $result = mysqli_query($connection, $sql)){
		     //mysqli_free_result($result);
		     echo ("<script LANGUAGE='JavaScript'> window.alert('Account Created Successfully!');
    			window.location.href='http://www.bz111.com:8080/html/login.html'; </script>");
	      }

	} else {
    		//echo "Server Error, please register later";
		echo ("<script LANGUAGE='JavaScript'> window.alert('Username has been taken Try another one!');
                        window.location.href='http://www.bz111.com:8080/html/login.html'; </script>");
	}
	mysqli_close($connection);
	
?>
