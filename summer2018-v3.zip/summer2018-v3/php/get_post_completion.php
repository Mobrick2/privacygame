<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Get Post Completion
	*/
	if ( !isset($_GET['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }
	
	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* Get the user's version. */
	$sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$version = $row["version"];

	/* Get the current character. */
	$sql = "select currentCharacter from users where uniqid = " . "'" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$currentCharacter = $row['currentCharacter'];

	/* Return the completion for that character. */
	$sql = "select " . $currentCharacter . "Completion from users where uniqid = " . "'" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$completion = $row[$currentCharacter . "Completion"];
	echo json_encode($completion);

	mysqli_free_result($result);
	mysqli_close($connection);

?>
