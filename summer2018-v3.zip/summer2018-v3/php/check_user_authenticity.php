<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Check Unique Id
	*/

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	if ( !isset($_POST["username"]) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}


	if ($_SERVER['REQUEST_METHOD'] != 'POST'){
		header('Location: http://www.bz111.com:8080/html/login.html');
                exit;		
	}

	$clientname = $_POST["username"];
	$clientpw = md5($_POST["password"]);

	/* Get the user's version. */
	$sql = "select * from loginUser where name= '$clientname' AND passwd='$clientpw'";
		
	$result =  mysqli_query($connection, $sql);

	if (mysqli_num_rows($result) == 0){ 
		echo ("<script LANGUAGE='JavaScript'> window.alert('Username or password is incorrect !');
                        window.location.href='http://www.bz111.com:8080/html/login.html'; </script>");		
	} else {
		/*keep the login status*/
		session_start();
		if (!isset($_SESSION['CREATED'])) {
   		    $_SESSION['CREATED'] = time();
		} else if (time() - $_SESSION['CREATED'] > 1800) {
    		    session_regenerate_id(true);
    		    $_SESSION['CREATED'] = time();
		}
		$_SESSION['nickname']=$clientname;
		header('Location: http://www.bz111.com:8080/php/personal_file.php');
	}
	mysqli_close($connection);
	mysqli_free_result($result);
	
?>
