<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Get Unique Id
	*/
	

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* chage the unique id to user login id*/
	//echo json_encode(uniqid());
	session_start();
	echo json_encode($_SESSION['nickname']);

	//mysqli_free_result($result);
	mysqli_close($connection);

?>
