drop table users;
create table users (
uniqid varchar(13),
version int,
aidenAnswers varchar(512),
aidenCompletion varchar(256),
lucasAnswers varchar(512),
lucasCompletion varchar(256),
oliviaAnswers varchar(512),
oliviaCompletion varchar(256),
sophiaAnswers varchar(512),
sophiaCompletion varchar(256),
currentCharacter varchar(256),
score int);
alter table users add primary key(uniqid, version);
alter ignore table users add unique(uniqid, version);