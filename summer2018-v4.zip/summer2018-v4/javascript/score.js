/*
	Dominik Jedruszczak
	Benjamin Knutson
	Score
*/

/* Refreshes the score according to the SQL entry. */
function refreshScore() {
	var P_score = document.getElementById("score");

	$.get("../php/get_score.php", {uniqueId : getCookie("uniqueId")}, function(score) {
		if (jQuery.parseJSON(score) != null) // In case initializing the user occurs before refreshing.
			P_score.innerHTML = "Score: " + jQuery.parseJSON(score); 
		/*set current score in cookie */
		document.cookie = "curScore=" + score + ";"
		
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

function findNextQuestion() {

	var x1 = getCookie("curScore");
	document.cookie = "preScore=" + x1 + ";"
	x1 = x1.substr(1,x1.length-2);
	var prescore = parseInt(x1);

	if ( prescore > 200 ) {
	    location.reload();
	}
        else{
	    //some operation in the databse
	}

        var cname = "Aiden";
	setCharacter(cname);
}

function findProQuestion() {

        
       	var x1 = getCookie("preScore");
        x3 = x1.substr(1,x1.length-2);
        var prescore = parseInt(x3);

	var x2 = getCookie("curScore");
        x4 = x2.substr(1,x2.length-2);
        var curscore = parseInt(x4);

	var diff = curscore-prescore;
        if ( diff > 200 ) {
            location.reload();
        }
        else{
            //some operation in the databse
        }

	document.cookie = "preScore=" + x2 + ";"
        var cname = "Sophia";
        setCharacter(cname);
}

