/*
	Dominik Jedruszczak
	Benjamin Knutson
	Unique Id
*/

/* Checks if there exists a unique id for this user. If not, create one.*/
function checkUniqueId() {
	$.get("../php/check_unique_id.php", {uniqueId : getCookie("uniqueId")}, function(needsUniqueId) {

		if (needsUniqueId.substring(0,8) == "se_unset"){
			window.location.replace("http://www.bz111.com:8080/html/login.html");
		}
		else if (needsUniqueId.substring(0,8) == "id_noeql"){
			$.get("../php/get_unique_id.php", function(uniqueId) {
                        
                           setCookie("uniqueId", jQuery.parseJSON(uniqueId), 7*24*60*60*1000*52); // One year.
                           //setCookie("uniqueId", jQuery.parseJSON(uniqueId), 7*24*60*60*1000*52); // One year.
                        
                           }).error(function(jqXHR, textStatus, errorThrown){
                                console.log(textStatus);
                                console.log(errorThrown);
                                   });   
			location.reload();
		}
		else if (needsUniqueId.substring(0,8) == "id_unset") {
			$.get("../php/get_unique_id.php", function(uniqueId) {

			//This maybe a bug from chrome, get_unique_id.php return a 13 characters, but chrome
			//change ths format
			setCookie("uniqueId", jQuery.parseJSON(uniqueId), 7*24*60*60*1000*52); // One year.
			//setCookie("uniqueId", jQuery.parseJSON(uniqueId), 7*24*60*60*1000*52); // One year.

			/* Create the SQL entry for the user.*/ 
			$.post("../php/user_init.php", {uniqueId : jQuery.parseJSON(uniqueId)}, function() {
					;
				}).error(function(jqXHR, textStatus, errorThrown){
					console.log(textStatus);
					console.log(errorThrown);
				});
			}).error(function(jqXHR, textStatus, errorThrown){
				console.log(textStatus);
				console.log(errorThrown);
			});
		}
	});
}

/* Create a new version for the user. */
function createNewVersion() {
	checkUniqueId();
	$.post("../php/user_init.php", {uniqueId : getCookie("uniqueId")}, function() {
		if (confirm("Once current process is rest, you will start a new process. Current processwill be saved as a history practice.")) {
   			window.location.reload();
		} 
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}
