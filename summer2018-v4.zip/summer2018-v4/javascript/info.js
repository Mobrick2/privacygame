/*

	Dominik Jedruszczak
	Benjamin Knutson
	Info

 */


/* Displays the info box for a page */
function info(){
  var infobox = document.getElementById("info_popup");
  if (infobox.getAttribute("style") == "display:none"){
    infobox.setAttribute("style", "");
  } else {
    infobox.setAttribute("style", "display:none");
  }
}

/* Shows info box automatically on first load */
function tutorial(page){
	var viewed = getCookie("viewed")
	if (viewed == undefined) {
		info();
		setCookie("viewed", setChar("00", page, "1"));
	}
	if (viewed.charAt(page) == "0") {
		info();
		setCookie("viewed", setChar(viewed, page, "1"));
	}

}

function setChar(str, index, character) {
    return str.substr(0, index) + character + str.substr(index+character.length);
}