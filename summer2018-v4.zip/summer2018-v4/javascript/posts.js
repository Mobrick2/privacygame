/*
	Dominik Jedruszczak
	Benjamin Knutson
	Posts
*/

function generatePosts() {
	/* Get the current character. */
	$.get("../php/get_current_character.php", {uniqueId : getCookie("uniqueId")}, function(currentCharacter) {
	    /* Get the character's posts. */
	    $.getJSON("../json/posts/" + $.parseJSON(currentCharacter) + ".json", function(posts) {
	    	/* Get the completion of the post's quiz. */
	    	$.get("../php/get_post_completion.php", {uniqueId : getCookie("uniqueId")}, function(completion) {
	    		completion = $.parseJSON(completion);
	    		console.log(completion);
		    	/* Generate the character's posts. */
		    	var UL_posts = document.getElementById("posts");
		    	/* Populate the posts. */
		    	for (var i = 0; i < posts.length; i++) { // For each post...
				
				 /* Grey out the post if it is completed. */
                                if (completion.charAt(i) == '2') {
                                        continue;
                                }

		    		/* Header. */
		    		var P_header = document.createElement("p");
		    		P_header.className = "postHeader";
		    		P_header.innerHTML = "Post # " + (i + 1) + " " + posts[i].header;

		    		/* Content. */
		    		/* Text. */
		    		var P_contentText = document.createElement("p");
		    		P_contentText.className = "contentText";
		    		P_contentText.innerHTML = posts[i].text;
		    		/* Image. */
		    		if (posts[i].image != null) {
			    		var IMG_contentImage = document.createElement("img");
			    		IMG_contentImage.className = "contentImage";
			    		IMG_contentImage.src = posts[i].image;
			    	}
		    		/* Geolocation. */
		    		var P_contentGeolocation = document.createElement("p");
		    		P_contentGeolocation.className = "contentGeolocation";
		    		P_contentGeolocation.innerHTML = posts[i].geolocation;
		    		/* Time. */
		    		var P_contentTime = document.createElement("p");
		    		P_contentTime.className = "contentTime";
		    		P_contentTime.innerHTML = posts[i].timestamp;
		    		/* - */
		    		var DIV_content = document.createElement("div");
		    		DIV_content.id = "content#" + i;
		    		DIV_content.className = "content";
		    		DIV_content.appendChild(P_contentText);
		    		if (posts[i].image != null != "")
		    			DIV_content.appendChild(IMG_contentImage);
		    		DIV_content.appendChild(P_contentGeolocation);
		    		DIV_content.appendChild(P_contentTime);


		    		/* Comments. */
		    		var UL_comments = document.createElement("ul");
		    		UL_comments.className = "comments";
		    		/* Populate the comments. */
		    		for (var j = 0; posts[i].comments != null && j < posts[i].comments.length; j++) { // For each comment...
		    			/* Comment. */
		    			/* Name. */
		    			var P_commentName = document.createElement("p");
		    			P_commentName.className = "commentName";
		    			P_commentName.innerHTML = posts[i].comments[j].name;
		    			/* Text. */
		    			var P_commentText = document.createElement("p");
		    			P_commentText.className = "commentText";
		    			P_commentText.innerHTML = posts[i].comments[j].text;
		    			/* Time. */
		    			var P_commentTime = document.createElement("p");
		    			P_commentTime.className = "commentTime";
		    			P_commentTime.innerHTML = posts[i].comments[j].time;
		    			/* - */
		    			var LI_comment = document.createElement("li");
		    			LI_comment.className = "comment";
		    			LI_comment.appendChild(P_commentName);
		    			LI_comment.appendChild(P_commentText);
		    			LI_comment.appendChild(P_commentTime);

		    			/* Comments. */
		    			UL_comments.appendChild(LI_comment);
		    		}

		    		/* Post. */
		    		var LI_post = document.createElement("li");
		    		LI_post.className = "post";
		    		LI_post.id = "post" + i;
		    		LI_post.setAttribute("onclick", "checkCurrentCharacter(createQuestionnaire, " + i + ")");
		    		LI_post.appendChild(P_header);
		    		LI_post.appendChild(DIV_content);
		    		LI_post.appendChild(UL_comments);

		    		/* Posts. */
		    		UL_posts.appendChild(LI_post);

		    		/* Grey out the post if it is completed. */
				/*
		    		if (completion.charAt(i) == '2') {
		    			greyOut(i);
		    		}
				*/
				break;
	    		}
	    		$.get("../php/get_score.php", {uniqueId : getCookie("uniqueId")}, function(score) {
					var userscore = "Score: " + jQuery.parseJSON(score); 
					var confirmation = "";
			      	if(completion.indexOf("0")==-1 && completion.indexOf("1")==-1){
			        switch ($.parseJSON(currentCharacter)) {
			          case "Sophia":
			            confirmation = "<b>Confirmation code: Sophia_rqrPiBTPPn_" + userscore + "</b>";
			            break;
			          case "Aiden":
			            confirmation = "<b>Confirmation code: Aiden_FmlDebTyws_" + userscore + "</b>";
			            break;
			          case "Olivia":
			            confirmation = "<b>Confirmation code: Olivia_r0w1j1GTpX_" + userscore + "</b>";
			            break;
			          case "Lucas":
			            confirmation = "<b>Confirmation code: Lucas_H7Huqx7ifl_" + userscore + "</b>";
			            break;
			        }
			        var HTML_confirmation_container = document.createElement("div");
			         var HTML_confirmation = document.createElement("p");
				      HTML_confirmation.innerHTML=confirmation;
				      HTML_confirmation.className = "post_wrapper";
				      HTML_confirmation.style.textAlign = "center";
				      HTML_confirmation.style.marginBottom = "10%";
				      var P_continue = document.createElement("p");
					  P_continue.className = "continue";
					  P_continue.innerHTML = "Continue";
					  P_continue.setAttribute("onclick", "document.body.removeChild(document.getElementById('popup'))");

					  HTML_confirmation_container.appendChild(HTML_confirmation);
					  HTML_confirmation_container.appendChild(P_continue);

				      createPopup(HTML_confirmation_container);
				  }
				}).error(function(jqXHR, textStatus, errorThrown){
					console.log(textStatus);
					console.log(errorThrown);
				});
	    	}).error(function(jqXHR, textStatus, errorThrown){
				console.log(textStatus);
				console.log(errorThrown);
			});
	    }).error(function(jqXHR, textStatus, errorThrown){
			console.log(textStatus);
			console.log(errorThrown);
		});
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

/* Grey out a post. */
function greyOut(index) {
	console.log("greying out post " + index);
	$("#post" + index).css('background','rgb(187, 187, 187)');
	$("#post" + index).css('color','black');
	$("#post" + index).find('*').css('background','rgb(187, 187, 187)');
    $("#post" + index).find('*').find('*').css('background','lightgrey');
    $("#post" + index).find('*').find('b').css('background','rgb(187, 187, 187)');
    $("#post" + index).find('*').find('.commentName').css('background','rgb(187, 187, 187)');
    $("#post" + index).find('img').css('filter', 'grayscale(100%)');
    $("#post" + index).find('img').css('-webkit-filter', 'grayscale(100%)');

    document.getElementById("post" + index).setAttribute("onclick", "checkCurrentCharacter(createReport, " + index + ")");
}

/* Un-grey out a post. */
function unGreyOut(post) {
	$(post).css('background','');
	$(post).css('color','');
	$(post).find('*').css('background','');
    $(post).find('*').find('*').css('background','');
    $(post).find('*').find('b').css('background','');
    $(post).find('*').find('.commentName').css('background','');
    $(post).find('img').css('filter', '');
    $(post).find('img').css('-webkit-filter', '');
}

/* Set the document's title to the name of the current character. */
function setTitle() {
	$.get("../php/get_current_character.php", {uniqueId : getCookie("uniqueId")}, function(currentCharacter) {
		document.title = $.parseJSON(currentCharacter);
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

/* If the page is displaying the current character, call the callback function with the specified parameter, otherwise, refresh the page. */
function checkCurrentCharacter(nextFunction, postIndex) {
	$.get("../php/get_current_character.php", {uniqueId : getCookie("uniqueId")}, function(currentCharacter) {
		if (document.title != $.parseJSON(currentCharacter))
			location.reload();
		else
			nextFunction(postIndex);
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}
