<?php
session_start();
if (!isset($_SESSION['CREATED'])){
   session_destroy();
   header('Location: http://www.bz111.com:8080/html/login.html');
}
//sesion active time is 30*60 seconds 
else if (time() - $_SESSION['CREATED'] > 1800) {
   session_unset(); 
   session_destroy(); 
   header('Location: http://www.bz111.com:8080/html/login.html');
}
else{
  $_SESSION['CREATED'] = time();
}

?>
<!DOCTYPE html>
<html>
   <head>
   <title> Personal Home Page</title>
   </head>
   <body>
   <b> Welcome : 
      <?php 
	echo $_SESSION['nickname']; 
      ?>
   </b>
   </br>
   <b><a href="/html/main_menu.html"> Practice More </a> </b>
   </br>
   <b> <a href="/php/logout.php">Log Out</a> </b>
   </body>
</html> 

