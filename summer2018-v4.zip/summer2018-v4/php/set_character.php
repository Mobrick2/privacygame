<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Set Character
	*/

	if ( !isset($_POST['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* Get the user's version. */
	$sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_POST['uniqueId']) . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$version = $row["version"];

	$sql = "update users set currentCharacter = '" . mysqli_real_escape_string($connection, $_POST['characterName']) . "' where uniqid = '" . mysqli_real_escape_string($connection, $_POST['uniqueId']) . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);

	mysqli_free_result($result);
	mysqli_close($connection);

?>
