<?php
	/*
		Bo Zhang
		Check login status
	*/

	/*the uniqueId cookie or session have never been set before or expired*/
	if ( !isset($_GET['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }
	
	
	session_start();
	if ( $_GET['uniqueId'] == $_SESSION['nickname'] && isset($_SESSION['CREATED']) &&
			(time() - $_SESSION['CREATED'] < 1800) ){
		echo "u_active";
	}
	else{
		echo "inactive";
	}

?>
