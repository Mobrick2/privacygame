<?php

 //var/www/html/depet/index.php

 //setcookie("uniqueId","55df709b98a9c", time() + (86400 * 30));
 if ( isset($_SESSION['CREATED'])) {
    header('Location: http://www.bz111.com:8080/html/main_menu.html'); 
 }
 else{
    header('Location: http://www.bz111.com:8080/html/login.html');
 }
 /*
 $has_session = session_status();

 if( $has_session == PHP_SESSION_ACTIVE ){
    header('Location: http://www.bz111.com:8080/html/main_menu.html');	
 }
 else{
    header('Location: http://www.bz111.com:8080/html/login.html');
 }
 */
 exit;
 ?>
