/*
	Dominik Jedruszczak
	Benjamin Knutson
	Score
*/

/* Refreshes the score according to the SQL entry. */
function refreshScore() {
	var P_score = document.getElementById("score");

	$.get("../php/get_score.php", {uniqueId : getCookie("uniqueId")}, function(score) {
		if (jQuery.parseJSON(score) != null) // In case initializing the user occurs before refreshing.
			P_score.innerHTML = "Score: " + jQuery.parseJSON(score); 
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}
