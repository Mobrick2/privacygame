function generatePostsHTML(username) {
  var filename = "../json/posts/" + username + ".json";
  console.log(filename);
  
  $.ajax({
    url: filename,
    datatype: "json",
    error: function (xhr, ajaxOptions, thrownError) {
        console.log(xhr.status);
        console.log(thrownError);
    },
    success: function(data) {
      var post_data = JSON.parse(data);
      
      var HTML_DIV_posts = document.getElementById("posts");
      for (var i = 0; i < post_data.length; i++) {
        var HTML_DIV_post_wrapper = document.createElement("div");
        HTML_DIV_post_wrapper.className="post_wrapper";
        HTML_DIV_post_wrapper.id = i.toString();
        
        var HTML_P_header = document.createElement("p");
        HTML_P_header.innerHTML = 'post #' + (i+1) + " " +post_data[i].header;
        HTML_P_header.className = "post_header";
        HTML_DIV_post_wrapper.appendChild(HTML_P_header);
        
        var HTML_DIV_post = document.createElement("div");
        HTML_DIV_post.className="post";
        HTML_DIV_post.id = "post"+i.toString();
        if (getCookie(username).charAt(i) == "2") {
          HTML_DIV_post_wrapper.setAttribute("onclick", "" );
        } else {
          HTML_DIV_post_wrapper.setAttribute("onclick", "createPopup("+ i.toString() + ")" );
        }
        
        /* Text. */
        var HTML_P_text = document.createElement("p");
        var HTML_P_TEXT_text = document.createTextNode(post_data[i].text);
        HTML_P_text.appendChild(HTML_P_TEXT_text);
        HTML_P_text.className="text";
        HTML_DIV_post.appendChild(HTML_P_text);
        
        /* Image. */
        
        if (post_data[i].image != null && post_data[i].image != "") {
          var HTML_IMG_image = document.createElement("img");
          HTML_IMG_image.src = post_data[i].image;
          HTML_DIV_post.appendChild(HTML_IMG_image);
        }
        
        
        /* Geolocation. */
        var HTML_P_geolocation = document.createElement("p");
        if (post_data[i].geolocation != null) {
          var HTML_P_TEXT_geolocation = document.createTextNode(post_data[i].geolocation);
          HTML_P_geolocation.appendChild(HTML_P_TEXT_geolocation);
        }
        HTML_DIV_post.appendChild(HTML_P_geolocation);
        
        /* Timestamp. */
        var HTML_P_timestamp = document.createElement("p");
        if (post_data[i].timestamp != null) {
          var HTML_P_TEXT_timestamp = document.createTextNode(post_data[i].timestamp);
          HTML_P_timestamp.appendChild(HTML_P_TEXT_timestamp);
        }
        HTML_P_timestamp.className="timestamp";
        HTML_DIV_post.appendChild(HTML_P_timestamp);
        HTML_DIV_post_wrapper.appendChild(HTML_DIV_post);
        
        if (post_data[i].comments != null){
          var HTML_DIV_comments = document.createElement("div");
          var HTML_UL_comment_list = document.createElement("ul");
          for(var j = 0; j < post_data[i].comments.length; j++){
            var HTML_LI_comment = document.createElement("li");
            var HTML_P_comment_name = document.createElement("p");
            HTML_P_comment_name.innerHTML=post_data[i].comments[j].name;
            HTML_LI_comment.appendChild(HTML_P_comment_name);
            var HTML_P_comment_text = document.createElement("p");
            HTML_P_comment_text.innerHTML=post_data[i].comments[j].text;
            HTML_LI_comment.appendChild(HTML_P_comment_text);
            var HTML_P_comment_time = document.createElement("p");
            HTML_P_comment_time.innerHTML=post_data[i].comments[j].time;
            HTML_P_comment_time.className = "comment_time";
            HTML_LI_comment.appendChild(HTML_P_comment_time);
            HTML_LI_comment.className="comment";
            HTML_UL_comment_list.appendChild(HTML_LI_comment);
          }
          HTML_UL_comment_list.className = "comments";
          HTML_DIV_comments.appendChild(HTML_UL_comment_list);
          HTML_DIV_post_wrapper.appendChild(HTML_DIV_comments);
        }
        HTML_DIV_posts.appendChild(HTML_DIV_post_wrapper);
      }
      
      for (var i = 0; i < post_data.length; i++) {
        if(getCookie(username).charAt(i) == "2"){
          $("#"+i.toString()).css('background','lightgrey');
          $("#"+i.toString()).find('*').css('background','lightgrey');
          $("#"+i.toString()).find('img').css('filter', 'grayscale(100%)');
          $("#"+i.toString()).find('img').css('-webkit-filter', 'grayscale(100%)');
        }
      }
      
  }
  });
}

function confirm() {
/* Confirmation code */
      var confirmation = "";
      if(getCookie(username).indexOf("0")==-1 && getCookie(username).indexOf("1")==-1){
        switch (username) {
          case "Sophia":
            confirmation = "<b>Confirmation code: Sophia_rqrPiBTPPn_" + getCookie("score") + "</b>";
            break;
          case "Aiden":
            confirmation = "<b>Confirmation code: Aiden_FmlDebTyws_" + getCookie("score") + "</b>";
            break;
          case "Olivia":
            confirmation = "<b>Confirmation code: Olivia_r0w1j1GTpX_" + getCookie("score") + "</b>";
            break;
          case "Lucas":
            confirmation = "<b>Confirmation code: Lucas_H7Huqx7ifl_" + getCookie("score") + "</b>";
            break;
        }
         var HTML_confirmation = document.createElement("p");
      HTML_confirmation.innerHTML=confirmation;
      HTML_confirmation.className = "post_wrapper";
      HTML_confirmation.style.textAlign = "center";
      HTML_confirmation.style.marginBottom = "10%";
      createPopup2(HTML_confirmation);
      }
      
     
}


