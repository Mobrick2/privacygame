/*

	Dominik Jedruszczak
	Benjamin Knutson
	Image Swapper

 */

/* On hover, swaps the image 1 for image 2 and vice versa*/
function image_swap (wrapper, image1, image2) {
	wrapper = $(wrapper)
	wrapper.hover(function() { 
			wrapper.attr('src', image2);
		},
		function() { 
			wrapper.attr('src', image1);
		});	
}