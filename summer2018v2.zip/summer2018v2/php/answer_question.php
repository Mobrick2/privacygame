<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Answer Question
	*/
	if ( !isset($_GET['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }
	
	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* Sanitize the input. */
	$uniqueId = mysqli_real_escape_string($connection, $_GET['uniqueId']);
	$question = mysqli_real_escape_string($connection, $_GET['question']);
	$answer = mysqli_real_escape_string($connection, $_GET['answer']);

	/* Get the user's version. */
	$sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$version = $row["version"];

	/* Get the current character. */
	$sql = "select currentCharacter from users where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$currentCharacter = $row['currentCharacter'];

	/* Get the current progression of the question. */
	$questionIndex = substr($question, 0, strlen($question) - 1); // The index of the question.
	$questionProgress = substr($question, -1, 1) + 1; // The new completion state of the question.
	$sql = "select " . $currentCharacter . "Completion from users where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$progress = $row[$currentCharacter . "Completion"];

	/* Create the new progression string. */
	if (substr($progress, $questionIndex, 1) == $questionProgress) { // Ensure the question has not already been answered.
		mysqli_close($connection);
		return;
	}
	$progress = substr($progress, 0, $questionIndex) . $questionProgress . substr($progress, $questionIndex + 1);

	/* Update the progression of the current character. */
	$sql = "update users set " . $currentCharacter . "Completion = '" . $progress . "' where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);

	/* Get the current selected answers of the character. */
	$sql = "select " . $currentCharacter . "Answers from users where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$answers = $row[$currentCharacter . "Answers"];

	/* Create the new answers string. */
	$answers = substr($answers, 0, (2 * $questionIndex) + ($questionProgress - 1)) . $answer . substr($answers, (2 * $questionIndex) + $questionProgress);

	/* Update the current selected answers of the character. */
	$sql = "update users set " . $currentCharacter . "Answers = '" . $answers . "' where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);

	/* Get the user's current score. */
	$sql = "select score from users where uniqid = " . "'" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$currentScore = $row['score'];

	/* Get the point value associated with the user's selection. */
	$sql = "select scores from " . strtolower($currentCharacter) . " where question = '" . $question . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$scores = $row['scores'];
	$score = substr($scores, $answer, 1);
	$score = $score != "X" ? $score * 10 : 100;

	/* Update the user's score. */
	$newScore = $currentScore + $score;
	$sql = "update users set score = " . $newScore . " where uniqid = '" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);

	/* Get the response associated with the user's selection. */
	$response = "response" . $answer;
	$sql = "select " . $response . " from " . strtolower($currentCharacter) . " where question = '" . $question . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$response = $row[$response];

	echo json_encode('{ "scores" : "' . $scores . '", "response" : "' . $response . '" }');

	mysqli_free_result($result);
	mysqli_close($connection);

?>
