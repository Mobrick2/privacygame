<?php
session_start();
if (!isset($_SESSION['CREATED'])){
   session_destroy();
   header('Location: http://www.bz111.com:8080/html/login.html');
}
//sesion active time is 30*60 seconds 
else if (time() - $_SESSION['CREATED'] > 1800) {
   session_unset();
   session_destroy();
   header('Location: http://www.bz111.com:8080/html/login.html');
}
else{
  $_SESSION['CREATED'] = time();
}

  /*Get the user's score of practices in last 7 practice*/
  $servername = "localhost";
  $username = "w3_depet";
  $password = "4RLpRUzv";
  $dbname = "w3_depet";

  $connection = mysqli_connect($servername, $username, $password, $dbname);
  if (!$connection) {
         die("Could not connect: " . mysqli_error($connection));
  }

  $sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_SESSION['nickname']) . "'";
  $result = mysqli_query($connection, $sql);
  $row = mysqli_fetch_array($result);

  $checknum = 10;
  if (isset($_GET['ChartCheck'])){
	$checknum = $_GET['ChartCheck'];
	if ($checknum > 20 ) $checknum=10;
  }
  $version = $row["version"]-$checknum;
	
  if ($version < 0) $version=-1;

  $sql = "select * from users where uniqid = " . "'" . mysqli_real_escape_string($connection, $_SESSION['nickname']) . "' and version > " . $version . " ORDER BY version ASC";

  $result = mysqli_query($connection, $sql);

  /* parse result */
  
  $labels = "";
  $values = "";
  $vecScore = array();
  $answer1 = array();
  $answer2 = array();
  $answer3 = array();
  $answer4 = array();
  $datelabel = array();
    
 
  while ($row = mysqli_fetch_array($result)){
     $values = $values . $row['score']. ",";
     $labels = $labels . "\"" . substr($row['startDate'],0,10) . "\"" . ",";
     array_push($vecScore,$row['score']);
     array_push($answer2,$row['aidenAnswers']);
     array_push($answer4,$row['lucasAnswers']);
     array_push($answer3,$row['oliviaAnswers']);
     array_push($answer1,$row['sophiaAnswers']);
     array_push($datelabel,substr($row['startDate'],0,10));
  }
  $labels = substr($labels,0, strlen($labels)-1);
  $values = substr($values,0, strlen($values)-1);

  mysqli_free_result($result);
  mysqli_close($connection);


  $arrlength=count($vecScore);
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../images/favicon.ico">

    <title>Personal profile page</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Welcome: 
	<?php
        echo $_SESSION['nickname'];
      	?>
      </a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="/php/logout.php">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Home<span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/html/main_menu.html">
                  <span data-feather="file"></span>
                  Practice
                </a>
              </li>
	      <!--
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="shopping-cart"></span>
                  Products
                </a>
              </li>
	      
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="users"></span>
                  Customers
                </a>
              </li>
	      --!>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="bar-chart-2"></span>
                  Reports
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="layers"></span>
                  Integrations
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Performance</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
	      <div class="dropdown">
  	      <a class="btn btn-sm btn-outline-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	      <span data-feather="database"></span>
    		Latest Scores
  	      </a>
		 <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    			<a class="dropdown-item" href="/php/personal_file.php?ChartCheck=5">Last 5 Trials</a>
    			<a class="dropdown-item" href="/php/personal_file.php?ChartCheck=10">Last 10 Trials</a>
    			<a class="dropdown-item" href="/php/personal_file.php?ChartCheck=20">Last 20 Trials</a>
  		 </div>
	      </div>
            </div>
          </div>

          <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>

          <h2>Score Details</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Sophia (Character)</th>
                  <th>Aiden (Character)</th>
                  <th>Olivia (Character)</th>
                  <th>Lucas (Character)</th>
		  <th>Total Score</th>
                </tr>
		<tr>
                  <th></th>
                  <th>High School Student</th>
                  <th>College Student</th>
                  <th>Young Adult</th>
                  <th>Adult</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
		<?php
		for($x=0;$x<$arrlength;$x++)
  		{
			echo "<tr>";
			echo "   <td>" . $datelabel[$x] ."</td>";
			echo "   <td>" . $answer1[$x] ."</td>";
			echo "   <td>" . $answer2[$x] ."</td>";
			echo "   <td>" . $answer3[$x] ."</td>";
			echo "   <td>" . $answer4[$x] ."</td>";
			echo "<td>". $vecScore[$x] . "</td>";
			echo "</tr>";
  		}
		?>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../javascript/jquery-slim.min.js"><\/script>')</script>
    <script src="../javascript/popper.min.js"></script>
    <script src="../javascript/bootstrap.min.js"></script>
    <script src="../javascript/jquery-1.7.1.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="../javascript/Chart.min.js"></script>
    <script>
      var ctx = document.getElementById("myChart");
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels:[ <?php echo $labels;?>],
          datasets: [{
            data: [ <?php echo $values; ?>],
            lineTension: 0,
            backgroundColor: 'transparent',
            borderColor: '#007bff',
            borderWidth: 4,
            pointBackgroundColor: '#007bff'
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: false
              }
            }]
          },
          legend: {
            display: false,
          }
        }
      });
    </script>
  </body>
</html>
