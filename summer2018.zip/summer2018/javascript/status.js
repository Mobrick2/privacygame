/*
	Bo Zhang
	Login Session 
	Credit to W3Schools.
*/

/* check current user session */
function checkLoginStatus() {
	$.get("../php/check_user_status.php", {uniqueId : getCookie("uniqueId")}, function(needsUniqueId) {

		if (needsUniqueId.substring(0,8) == "u_active" ){
			window.location.replace("http://www.bz111.com:8080/php/personal_file.php");
		}
	});	
}
