/*
	Dominik Jedruszczak
	Benjamin Knutson
	Progress
*/

/* Resets the user's progress. */
function resetProgress() {
	$.post("../php/reset_progress.php", {uniqueId : getCookie("uniqueId")}, function() {
		refreshScore();
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}