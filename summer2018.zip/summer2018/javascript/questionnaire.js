/*
	Dominik Jedruszczak
	Benjamin Knutson
	Questionnaire
*/

/* Creates a popup containing the questionnaire for a post. */
function createQuestionnaire(postIndex) {
	/* Clone the post. */
	var post = document.getElementById("post" + postIndex).cloneNode(true);
	post.onclick = null; // Prevent opening a second popup by clicking on the clone.

	/* Q and A. */
	var DIV_qanda = document.createElement("div");
	DIV_qanda.id = "qanda";
	createQanda(postIndex); // Generate the Q and A asynchronously.

	/* Questionnaire. */
	var DIV_questionnaire = document.createElement("div");
	DIV_questionnaire.id = "questionnaire";
	DIV_questionnaire.appendChild(post);
	DIV_questionnaire.appendChild(DIV_qanda);

	/* Create the popup for the questionnaire. */
	createPopup(DIV_questionnaire);
}

/* Create and return the question and answer portion of the questionnaire. */
function createQanda(postIndex) {
	/* Get the current character. */
	$.get("../php/get_current_character.php", {uniqueId : getCookie("uniqueId")}, function(currentCharacter) {
	    /* Get the character's posts. */
	    $.getJSON("../json/posts/" + $.parseJSON(currentCharacter) + ".json", function(posts) {
	    	/* Get the completion of the post's quiz. */
	    	$.get("../php/get_post_completion.php", {uniqueId : getCookie("uniqueId")}, function(completion) {
	    		completion = $.parseJSON(completion);

	    		/* Question. */
	    		var P_question = document.createElement("p");
	    		P_question.className = "question";

	    		/* Answers. */
	    		var UL_answers = document.createElement("ul");
	    		UL_answers.id = "answers";

	    		/* Continue. */
	    		var P_continue = document.createElement("p");
	    		P_continue.className = "continue";
	    		P_continue.id = "continue";
	    		P_continue.innerHTML = "Continue";

	    		if (completion.charAt(postIndex) == '0') { // If the user has not answered either question.
	    			/* Question. */
	    			P_question.innerHTML = posts[postIndex].question1;

	    			/* Answers. */
	    			for (var i = 0; i < 4 /* Always 4 answers to a question. */; i++) {
	    				/* Text. */
	    				var P_text = document.createElement("p");
	    				P_text.innerHTML = posts[postIndex].options1[i];
	    				/* Answer. */
	    				var LI_answer = document.createElement("li");
	    				LI_answer.className = "answer";
	    				LI_answer.setAttribute("onclick", "toggleAnswer(" + i + ")");
	    				LI_answer.appendChild(P_text);
	    				/* Answers. */
	    				UL_answers.appendChild(LI_answer);
	    				/* Continue. */
	    				P_continue.setAttribute("onclick", "answerQuestion('" + postIndex + "0')");
	    			}
	    		}
	    		else if (completion.charAt(postIndex) == '1') { // If the user has answered the first question. 
	    			/* Question. */
	    			P_question.innerHTML = posts[postIndex].question2;

	    			/* Answers. */
	    			for (var i = 0; i < 4 /* Always 4 answers to a question. */; i++) {
	    				/* Text. */
	    				var P_text = document.createElement("p");
	    				P_text.innerHTML = posts[postIndex].options2[i];
	    				/* Answer. */
	    				var LI_answer = document.createElement("li");
	    				LI_answer.className = "answer";
	    				LI_answer.setAttribute("onclick", "toggleAnswer(" + i + ")");
	    				LI_answer.appendChild(P_text);
	    				/* Answers. */
	    				UL_answers.appendChild(LI_answer);
	    				/* Continue. */
	    				P_continue.setAttribute("onclick", "answerQuestion('" + postIndex + "1'); greyOut('" + postIndex + "')");
	    			}
	    		}

	    		/* Q and A. */
	    		var DIV_qanda = document.getElementById("qanda");
	    		DIV_qanda.id = "qanda";
	    		DIV_qanda.appendChild(P_question);
	    		DIV_qanda.appendChild(UL_answers);
	    		DIV_qanda.appendChild(P_continue);
	    	}).error(function(jqXHR, textStatus, errorThrown){
				console.log(textStatus);
				console.log(errorThrown);
			});
	    }).error(function(jqXHR, textStatus, errorThrown){
			console.log(textStatus);
			console.log(errorThrown);
		});
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

/* Answer a question. */
function answerQuestion(question) {
	if (getCookie("currentAnswer") != "") { // If the user has selected an answer...
		/* Answer the question and get back the score and response. */
		$.get("../php/answer_question.php", {uniqueId : getCookie("uniqueId"), question : question, answer : getCookie("currentAnswer")}, function(solution) {
			solution = JSON.parse(JSON.parse(solution));

			var DIV_feedback = document.createElement("div");
			DIV_feedback.id = "feedback";

			/* Score. */
			score = solution.scores.charAt(getCookie("currentAnswer"));
			if (score == "X") {
				score = 10;
			}
			score = parseInt(score);

			var P_score = document.createElement("p");
			P_score.className = "reportScore";
			P_score.innerHTML = "<b>" + score*10 + "/100</b>";
			P_score.style.color = "rgba("+ 25*(10-score) + "," + 25*score +",0,1)";
			DIV_feedback.appendChild(P_score);


			/* Response. */
			var P_response = document.createElement("p");
			P_response.id = "response";
			P_response.innerHTML = solution.response;
			DIV_feedback.appendChild(P_response);

			/* Q and A. */
			var qanda = document.getElementById("qanda");
			qanda.insertBefore(DIV_feedback, document.getElementById('continue'))

			/* Recolor the option based on what the user selected and the correct answer. */
			var answers = document.getElementById("answers");
			var correctAnswer = solution.scores.indexOf('X');
			var answer = getCookie("currentAnswer");
			for (var i = 0, currentChild = answers.firstChild; i < 4; i++, currentChild = currentChild.nextSibling) {
				if (i == answer)
					currentChild.style.borderColor = "red";
				if (i == correctAnswer) 
					currentChild.style.borderColor = "green";
				currentChild.onclick = "";
			}

			/* Change the continue button's text to it's default in case the user had not previously selected an option. */
			document.getElementById('continue').innerHTML = "Continue";

			/* Continue. */
			if (question.charAt(question.length - 1) == '0') // First question.
				document.getElementById("continue").setAttribute("onclick", "document.getElementById('qanda').innerHTML = ''; document.body.style.overflow='auto'; createQanda('" + question.substring(0, question.length - 1) + "'); setCookie('currentAnswer', '')");
			else  // Second question.
				document.getElementById("continue").setAttribute("onclick", "document.body.removeChild(document.getElementById('popup')); document.body.style.overflow='auto'; setCookie('currentAnswer', '')");

			refreshScore();
		}).error(function(jqXHR, textStatus, errorThrown){
			console.log(textStatus);
			console.log(errorThrown);
		});
	}
	else {
		document.getElementById('continue').innerHTML = "Please select an option to continue."; // Let the user know they haven't selected an answer.
	}
}

/* Toggle an answer. */
function toggleAnswer(index) {
	setCookie("currentAnswer", index.toString());
	for (var i = 0, j=document.getElementById("answers").firstChild; j!=null; j=j.nextSibling, i++){
		if (i == index){
	      j.style.border = "2px solid #3E6187";
	    } else {
	      j.style.border = "2px solid #CEE0F5";
	    }
	}
}