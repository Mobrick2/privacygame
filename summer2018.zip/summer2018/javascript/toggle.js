/* Toggle an answer. */
function toggleAnswer(index) {
	setCookie("currentAnswer", index.toString());
	for (var i = 0, j=document.getElementById("answers").firstChild; j!=null; j=j.nextSibling, i++){
		if (i == index){
	      j.style.border = "2px solid #3E6187";
	    } else {
	      j.style.border = "2px solid #CEE0F5";
	    }
	}
}