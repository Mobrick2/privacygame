/*

	Dominik Jedruszczak
	Benjamin Knutson
	Popup

 */

/* Generates a popup from a given HTML object */
function createPopup (content) {

	//Removes the scroll bar while the popup is open	
	document.body.style.overflow="hidden";

	var popup_background = document.createElement("div");
	popup_background.className="popup";
	popup_background.id="popup";
	//Closes the popup if the user clicks off of it, and restores the scrollbar to the body.
	popup_background.setAttribute("onclick", "document.body.removeChild(this); \
                                       document.body.style.overflow='auto';");

	var popup_visible = document.createElement("div");
	popup_visible.className = "visible";
	//Stops the popup from closing if the user clicks on it.
	popup_visible.onclick = function(e){
          if (!e) var e = window.event;
          e.cancelBubble = true;
          if (e.stopPropagation) e.stopPropagation();
        };
    popup_visible.appendChild(content);
    popup_background.appendChild(popup_visible);
    document.body.appendChild(popup_background);
}