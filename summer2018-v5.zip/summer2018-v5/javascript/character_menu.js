/*
	Dominik Jedruszczak
	Benjamin Knutson
	Character Menu
*/

/* Generates the character menu. */
function generateCharacterMenu() {
	$.getJSON("../json/characters.json", function(characters) {
		var DIV_characters = document.getElementById("characters");

		/* Populate the character menu. */
		for (var i = 0; i < characters.length; i++) { // For each character...
			/* Image. */
			var IMG_image = document.createElement("img");
			IMG_image.src = characters[i].image;

			/* Name. */
			var P_name = document.createElement("p");
			P_name.className = "name";
			P_name.innerHTML = characters[i].name;

			/* Tagline. */
			var P_tagline = document.createElement("p");
			P_tagline.className = "tagline";
			P_tagline.innerHTML = characters[i].tagline;

			/* Character. */
			var DIV_character = document.createElement("div");
			DIV_character.className = "character";
			DIV_character.setAttribute("onclick", "selectCharacter('" + characters[i].name + "', '" + characters[i].bio + "', '" + characters[i].privacyTopics + "')");
			DIV_character.appendChild(IMG_image);
			DIV_character.appendChild(P_name);
			DIV_character.appendChild(P_tagline);
			
			/* Characters. */
			DIV_characters.appendChild(DIV_character);
		}
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

/* Selects a character and displays their bio. */
function selectCharacter(name, bio, privacyTopics) {
	/* Bio. */
	var P_bio = document.createElement("p");
	P_bio.className = "bio";
	P_bio.innerHTML = bio;

	/* Security topics. */
	var P_privacyTopics = document.createElement("p");
	P_privacyTopics.className = "privacyTopics";
	P_privacyTopics.innerHTML = "Privacy topics: " + privacyTopics;

	/* X. */
	var IMG_x = document.createElement("img");
	IMG_x.className = "x";
	IMG_x.src = "../images/x.png";
	IMG_x.setAttribute("onclick", "document.body.removeChild(document.getElementById('popup'))");

	/* Continue. */
	var P_continue = document.createElement("p");
	P_continue.className = "continue";
	P_continue.innerHTML = "Continue to Profile";
	P_continue.setAttribute("onclick", "setCharacter('" + name + "')");

	/* Content. */
	var DIV_content = document.createElement("div");
	DIV_content.appendChild(P_bio);
	DIV_content.appendChild(document.createElement("br"));
	DIV_content.appendChild(P_privacyTopics);
	DIV_content.appendChild(IMG_x);
	DIV_content.appendChild(P_continue);

	createPopup(DIV_content);
}

/* Sets the current character. */
function setCharacter(name) {
	$.post("../php/set_character.php", {uniqueId : getCookie("uniqueId"), characterName : name}, function() {
		window.location = "other_profile.html"; // Redirect to the character profile.
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}
