/*
	Dominik Jedruszczak
	Benjamin Knutson
	Score
*/

/* Refreshes the score according to the SQL entry. */
function refreshScore() {
	var P_score = document.getElementById("score");
	
	$.get("../php/get_score.php", {uniqueId : getCookie("uniqueId")}, function(score) {
		if (jQuery.parseJSON(score) != null) // In case initializing the user occurs before refreshing.
			P_score.innerHTML = "Score: " + jQuery.parseJSON(score); 
		/*set current score in cookie */
		document.cookie = "curScore=" + score + ";"
		
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}

function findNextQuestion() {
	var difflevel = "112114445345553533222";
	var x1 = getCookie("curScore");
	document.cookie = "preScore=" + x1 + ";"
	x1 = x1.substr(1,x1.length-2);
	var pscore = parseInt(x1);

	var answer = "";
	$.ajaxSetup({async:false});
	$.get("../php/get_history.php", {uniqueId : getCookie("uniqueId")},function(result) {
		answer = jQuery.parseJSON(result); 		
	});

	var firstdiff = -1;
	if (pscore < 100) {
		firstdiff = 1;
	}
	else if (pscore >= 100 && pscore < 200) {
		firstdiff = 2;
	}
	else if(pscore >= 200 && pscore < 300){
		firstdiff = 3;
	}
	else if(pscore >=300 && pscore < 400){
		firstdiff = 4;
	}
	else{
		firstdiff = 5;
	}

	var firstq = -1;
	var secondq = 6;
	for (var i=0;i<answer.length;i++){
		if (difflevel.charAt(answer[i]) == firstdiff){
			firstq = answer[i];
			break;
		}
		else if (difflevel.charAt(answer[i]) >  firstdiff){
			if ( answer[i] < secondq ){
				secondq = answer[i] ;
			}
		} 
	}
	
	if ( firstq == -1 && secondq != 6 ) firstq = secondq; 

	if ( firstq != -1 ) document.cookie = "predifflevel=" + difflevel.charAt(firstq) + ";"
	else{
		var difflevel = -1;
		document.cookie = "predifflevel=" + difflevel + ";"
	}
  	//document.cookie = "predifflevel2=" + firstdiff + ";"
	//document.cookie = "firstq=" + firstq + ";"
	var cname = "";
	var post_index = -1 ;
	if (firstq >= 0 && firstq < 5) {
		cname ="Sophia";
		post_index = firstq;
	}
	else if (firstq >= 5 && firstq < 10){
		cname = "Aiden";
		post_index = firstq-5;
	}
	else if(firstq >= 10 && firstq < 15){
		cname = "Olivia";
		post_index = firstq-10;
	}
	else {
		cname = "Lucas";
		post_index = firstq-15;
	}	
	//alert("result:" + answer + " diff:" + difflevel.charAt(firstq) + " firstq:" + firstq);
	if ( answer.length == 0 || firstq < 0 ) {
		var index = -1;
		document.cookie = "postindex=" + index + ";"
	}
	else{
	       document.cookie = "postindex=" + post_index + ";"

	}
	
	document.cookie = "availableQ=" + answer.length + ";"
	setCharacter(cname);
	
}

function findProQuestion() {
	var difflevel = "112114445345553533222";
       	var x1 = getCookie("preScore");
        x3 = x1.substr(1,x1.length-2);
        var prescore = parseInt(x3);

	var x2 = getCookie("curScore");
        x4 = x2.substr(1,x2.length-2);
        var curscore = parseInt(x4);

	var diff = curscore-prescore;

	var answer = "";
	$.ajaxSetup({async:false});
	$.get("../php/get_history.php", {uniqueId : getCookie("uniqueId")},function(result) {
		answer = jQuery.parseJSON(result); 		
	});

	var preQcount = getCookie("availableQ");
	var curQcount = answer.length;

	if ( preQcount != curQcount ){
	document.cookie = "preScore=" + x2 + ";"

     	var currdiff = getCookie("predifflevel");
	var nextdiff = currdiff;

	if (diff<50) {
		nextdiff = currdiff - 1;
	}
	else if (diff >= 50 && diff <= 150) {
		nextdiff = currdiff;
	}
	else if(diff > 150){
		nextdiff = currdiff + 1;
	}

	var nextq = -1;
	var secondq = 6;
	for (var i=0;i<answer.length;i++){
		if (difflevel.charAt(answer[i]) == nextdiff){
			nextq = answer[i];
		}
		else if (difflevel.charAt(answer[i]) >  nextdiff){
                        if ( answer[i] < secondq ){
                                secondq = answer[i] ;
                        }
                }
	}

	if ( nextq == -1 && secondq != 6 ) nextq = secondq;
	if ( nextq != -1 ) document.cookie = "predifflevel=" + difflevel.charAt(nextq) + ";"
        else{
                var difflevel = -1;
                document.cookie = "predifflevel=" + difflevel + ";"
        }


	var cname = "";
        var post_index = -1;
	if (nextq >= 0 && nextq < 5) {
		cname ="Sophia";
		post_index = nextq;
	}
	else if (nextq >= 5 && nextq < 10){
		cname = "Aiden";
		post_index = nextq-5;
	}
	else if(nextq >= 10 && nextq < 15){
		cname = "Olivia";
		post_index = nextq-10;
	}
	else {
		cname = "Lucas";
		post_index = nextq-15;
	}	

	//alert("result:" + answer + " diff:" + difflevel.charAt(firstq)  + " nextq:" + nextq);
	if ( answer.length == 0 || nextq < 0 ) {
                var index = -1;
                document.cookie = "postindex=" + index + ";"
        }
        else{
               document.cookie = "postindex=" + post_index + ";"

        }
	
	setCharacter(cname);
	}
	else{
		location.reload();
	}
}

