/*
	Dominik Jedruszczak
	Benjamin Knutson
	Report
*/

/* Create a popup containing the report. */
function createReport(postIndex) {
	/* Return the data necessary to create the report. */
	$.get("../php/get_posts_answers.php", {uniqueId : getCookie("uniqueId"), postIndex : postIndex}, function(data) {
		data = $.parseJSON($.parseJSON(data)); console.log(data);
	    /* Get the current character's posts. */
	    $.getJSON("../json/posts/" + data.currentCharacter + ".json", function(posts) {
		    if (data != null) {
		    	/* Clone the post. */
				var post = document.getElementById("post" + postIndex).cloneNode(true);
				post.onclick = null; // Prevent opening a second popup by clicking on the clone.
				unGreyOut(post); // Remove the grayscale filter of completed posts.

				/* Report 1. Reports cannot be generated dynamically due to JSON structure (posts[postIndex].question1 vs. posts[postIndex].question2, etc.). */
				/* Question. */
				var P_question1 = document.createElement("p");
				P_question1.className = "question";
				P_question1.innerHTML = posts[postIndex].question1;
				/* Answers. */
				var UL_answers1 = document.createElement("ul");
				UL_answers1.className = "answers";
				for (var i = 0; i < 4 /* Always 4 answers to a question. */; i++) {
    				/* Text. */
    				var P_text = document.createElement("p");
    				P_text.innerHTML = posts[postIndex].options1[i];
    				/* Answer. */
    				var LI_answer = document.createElement("li");
    				LI_answer.className = "inertAnswer";
    				LI_answer.appendChild(P_text);
    				/* Color the answers based on the user selected option and the correct option. */
    				if (i == data.userOptions[0])
						LI_answer.style.borderColor = "red";
					if (i == data.correctOptions[0]) 
						LI_answer.style.borderColor = "green";
    				/* Answers. */
    				UL_answers1.appendChild(LI_answer);
    			}
    			/* Score. */
    			var P_score1 = document.createElement("p");
    			P_score1.className = "reportScore";
    			P_score1.innerHTML = "<b>" + data.scores[0] * 10 + "/100</b>";
				P_score1.style.color = "rgba(" + 25 * (10 - data.scores[0]) + "," + 25 * data.scores[0] + ",0,1)";
    			/* Response. */
    			var P_response1 = document.createElement("p");
    			P_response1.className = "response";
    			P_response1.innerHTML = data.responses[0];
    			/* Report. */
				var DIV_report1 = document.createElement("div");
				DIV_report1.className = "subreport";
				DIV_report1.appendChild(P_question1);
				DIV_report1.appendChild(UL_answers1);
				DIV_report1.appendChild(P_score1);
				DIV_report1.appendChild(P_response1);

				/* Report 2. */
				/* Question. */
				var P_question2 = document.createElement("p");
				P_question2.className = "question";
				P_question2.innerHTML = posts[postIndex].question2;
				/* Answers. */
				var UL_answers2 = document.createElement("ul");
				UL_answers2.className = "answers";
				for (var i = 0; i < 4 /* Always 4 answers to a question. */; i++) {
    				/* Text. */
    				var P_text = document.createElement("p");
    				P_text.innerHTML = posts[postIndex].options2[i];
    				/* Answer. */
    				var LI_answer = document.createElement("li");
    				LI_answer.className = "inertAnswer";
    				LI_answer.appendChild(P_text);
    				/* Color the answers based on the user selected option and the correct option. */
    				if (i == data.userOptions[1])
						LI_answer.style.borderColor = "red";
					if (i == data.correctOptions[1]) 
						LI_answer.style.borderColor = "green";
    				/* Answers. */
    				UL_answers2.appendChild(LI_answer);
    			}
    			/* Response. */
    			var P_response2 = document.createElement("p");
    			P_response2.className = "response";
    			P_response2.innerHTML = data.responses[1];
    			/* Score. */
    			var P_score2 = document.createElement("p");
    			P_score2.className = "reportScore";
    			P_score2.innerHTML = "<b>" + data.scores[1] * 10 + "/100</b>";
				P_score2.style.color = "rgba(" + 25 * (10 - data.scores[1]) + "," + 25 * data.scores[1] + ",0,1)";
    			/* Report. */
				var DIV_report2 = document.createElement("div");
				DIV_report2.className = "subreport";
				DIV_report2.appendChild(P_question2);
				DIV_report2.appendChild(UL_answers2);
				DIV_report2.appendChild(P_score2);
				DIV_report2.appendChild(P_response2);

				/* Continue. */
				var P_continue = document.createElement("p");
				P_continue.className = "continue";
				P_continue.innerHTML = "Continue";
				P_continue.setAttribute("onclick", "document.body.removeChild(document.getElementById('popup'))");

				/* Report. */
				var DIV_report = document.createElement("div");
				DIV_report.id = "report";
				DIV_report.appendChild(post);
				DIV_report.appendChild(DIV_report1);
				DIV_report.appendChild(document.createElement("hr"));
				DIV_report.appendChild(DIV_report2);
				DIV_report.appendChild(P_continue);

				createPopup(DIV_report);
			}
		}).error(function(jqXHR, textStatus, errorThrown){
			console.log(textStatus);
			console.log(errorThrown);
		});
	}).error(function(jqXHR, textStatus, errorThrown){
		console.log(textStatus);
		console.log(errorThrown);
	});
}