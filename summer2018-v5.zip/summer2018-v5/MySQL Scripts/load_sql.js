function generate () {
	var query = "";
	$.getJSON("../json/posts/Sophia.json", function(posts) {
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update sophia set response" + j + "=\""+posts[i].responses1[j]+"\" where question ="+ i+ "0;\n";
			}
		}
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update sophia set response" + j + "=\""+posts[i].responses2[j]+"\" where question ="+ i+ "1;\n";
			}
		}
	});
	$.getJSON("../json/posts/Olivia.json", function(posts) {
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update olivia set response" + j + "=\""+posts[i].responses1[j]+"\" where question ="+ i+ "0;\n";
			}
		}
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update olivia set response" + j + "=\""+posts[i].responses2[j]+"\" where question ="+ i+ "1;\n";
			}
		}
	});
	$.getJSON("../json/posts/Lucas.json", function(posts) {
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update lucas set response" + j + "=\""+posts[i].responses1[j]+"\" where question ="+ i+ "0;\n";
			}
		}
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update lucas set response" + j + "=\""+posts[i].responses2[j]+"\" where question ="+ i+ "1;\n";
			}
		}
	});
	$.getJSON("../json/posts/Aiden.json", function(posts) {
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update aiden set response" + j + "=\""+posts[i].responses1[j]+"\" where question ="+ i+ "0;\n";
			}
		}
		for(var i=0; i<posts.length; i++){
			for(var j=0; j<4; j++){
				query += "update aiden set response" + j + "=\""+posts[i].responses2[j]+"\" where question ="+ i+ "1;\n";
			}
		}
	});
	window.setTimeout(function(){
		console.log(query);
	}, 1000)
}