<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Get Score
	*/
	/*
	if ( !isset($_GET['uniqueId']) ){
		die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
	}
	*/

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* Get the user's version. */
	$sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$version = $row["version"];

	$sql = "select * from users where uniqid = " . "'" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "' and version = " . $version;

	$result = mysqli_query($connection, $sql);

	$row = mysqli_fetch_array($result);
	$answer = $row['sophiaAnswers'];
	$answer.=$row['aidenAnswers'];
	$answer.=$row['oliviaAnswers'];
	$answer.=$row['lucasAnswers'];
	
	$unanswered = array();
	for ($i=0;$i<strlen($answer);$i++) {
	  $s = substr($answer,$i,1);
	  if ( $s == 'X' and $i%2==0 ){
		array_push($unanswered,$i/2);
	  }
    }
	echo json_encode($unanswered);

	mysqli_free_result($result);
	mysqli_close($connection);

?>
