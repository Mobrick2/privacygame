<?php
$servername = "localhost";
$username = "w3_depet";
$password = "4RLpRUzv";
$dbname = "w3_depet";

$connection = mysqli_connect($servername, $username, $password, $dbname);
if (!$connection) {
	die("Could not connect: " . mysqli_error($connection));
}

/*$sql = "select * from sophia";
$result = mysqli_query($connection, $sql);
if ($result == FALSE) {
	echo json_encode(broken);
}

$string = "";
while($row = mysqli_fetch_array($result)) {
	$string = $string . ($row['question']);
}

echo json_encode($string);*/

$sql = "insert into test values(7)";
$result = mysqli_query($connection, $sql);

mysqli_free_result($result);
mysqli_close($connection);
?>
