<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Reset Progress
	*/

	if ( !isset($_POST['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}


	// Counts the number of posts in each character and generates answer and progress strings for all of them.
	$aidenPostCount = count(json_decode(file_get_contents("../json/posts/Aiden.json"), true));
	$aidenAnswersString = str_repeat("X", $aidenPostCount*2);
	$aidenProgressString = str_repeat("0", $aidenPostCount);

	$lucasPostCount = count(json_decode(file_get_contents("../json/posts/Lucas.json"), true));
	$lucasAnswersString = str_repeat("X", $lucasPostCount*2);
	$lucasProgressString = str_repeat("0", $lucasPostCount);

	$oliviaPostCount = count(json_decode(file_get_contents("../json/posts/Olivia.json"), true));
	$oliviaAnswersString = str_repeat("X", $oliviaPostCount*2);
	$oliviaProgressString = str_repeat("0", $oliviaPostCount);

	$sophiaPostCount = count(json_decode(file_get_contents("../json/posts/Sophia.json"), true));
	$sophiaAnswersString = str_repeat("X", $sophiaPostCount*2);
	$sophiaProgressString = str_repeat("0", $sophiaPostCount);
	
	$sql = "update users set 
	aidenAnswers = '" . $aidenAnswersString . "',
	aidenCompletion = '" . $aidenProgressString . "',
	lucasAnswers = '" . $lucasAnswersString . "',
	lucasCompletion = '" . $lucasProgressString . "',
	oliviaAnswers = '" . $oliviaAnswersString . "',
	oliviaCompletion = '" . $oliviaProgressString . "',
	sophiaAnswers = '" . $sophiaAnswersString . "',
	sophiaCompletion = '" . $sophiaProgressString . "',
	score = 0 where uniqid = '" . mysqli_real_escape_string($connection, $_POST['uniqueId']) . "'";
	$result = mysqli_query($connection, $sql);
	

	mysqli_free_result($result);
	mysqli_close($connection);

?>
