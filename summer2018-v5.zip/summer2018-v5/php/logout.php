<?php
   session_start();
   session_unset();
   session_destroy();
   header('Location: http://www.bz111.com:8080/html/login.html');
   exit;
?>
