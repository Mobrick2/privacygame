<?php

	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Reset Progress
	*/
	if ( !isset($_GET['uniqueId']) ){
                die ("Direct access not permitted. Contact bzhang41 AT stevens DOT edu");
        }

	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/* Sanitize the input. */
	$uniqueId = mysqli_real_escape_string($connection, $_GET['uniqueId']);
	$postIndex = mysqli_real_escape_string($connection, $_GET['postIndex']);

	/* Get the user's version. */
	$sql = "select max(version) as version from users where uniqid = '" . $uniqueId . "'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$version = $row["version"];

	/* Get the current character. */
	$sql = "select currentCharacter from users where uniqid = '" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$currentCharacter = $row['currentCharacter'];

	/* Make sure the user has completed the post's questions. */
	$sql = "select " . $currentCharacter . "Completion from users where uniqid = '" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$completion = $row[$currentCharacter . "Completion"];
	$completion = substr($completion, $postIndex, 1);
	if (strcmp($completion, "2") != 0) { // If the user has not completed the question...
		mysqli_close($connection);
		return;
	}
		
	/* Get the indices of each posts' correct option. */
	$sql = "select scores from " . strtolower($currentCharacter) . " where question = '" . $postIndex  . "0' OR question = '" . $postIndex . "1'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$score1 = $row['scores'];
	$correctOption1 = strpos($score1, "X"); // First question.
	$row = mysqli_fetch_array($result);
	$score2 = $row['scores'];
	$correctOption2 = strpos($score2, "X"); // Second question.

	/* Get the indices of each posts' user option. */
	$sql = "select " . $currentCharacter . "Answers from users where uniqid = '" . $uniqueId . "' and version = " . $version;
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$userAnswers = $row[$currentCharacter . "Answers"];
	$userOption1 = substr($userAnswers, 2 * $postIndex, 1);
	$userOption2 = substr($userAnswers, (2 * $postIndex) + 1, 1);

	/* Get the user's scores. */
	$score1 = substr($score1, $userOption1, 1);
	$score1 = (strcmp($score1, "X") == 0) ? 10 : $score1;
	$score2 = substr($score2, $userOption2, 1);
	$score2 = (strcmp($score2, "X") == 0) ? 10 : $score2;

	/* Get the responses for each user's option. */
	$response = "response" . $userOption1;
	$sql = "select " . $response . " from " . strtolower($currentCharacter) . " where question = '" . $postIndex . "0'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$response1 = $row[$response];
	$response = "response" . $userOption2;
	$sql = "select " . $response . " from " . strtolower($currentCharacter) . " where question = '" . $postIndex . "1'";
	$result = mysqli_query($connection, $sql);
	$row = mysqli_fetch_array($result);
	$response2 = $row[$response];

	/* Format information into JSON. */
	echo json_encode(
	'{' .
		'"currentCharacter" : "' .
			$currentCharacter . '", ' .
		'"correctOptions" : ' . 
		'[' .
			$correctOption1 . ', ' .
			$correctOption2 .
		'], ' .
		'"userOptions" : ' . 
		'[' .
			$userOption1 . ', ' .
			$userOption2 . 
		'], ' .
		'"scores" : ' .
		'[' .
			$score1 . ', ' .
			$score2 . 
		'], ' .
		'"responses" : ' .
		'[' .
			'"' . $response1 . '", ' .
			'"' . $response2 . '"' .
		']' .
	'}');

	mysqli_free_result($result);
	mysqli_close($connection);

?>
