<?php
	/*
		Dominik Jedruszczak
		Benjamin Knutson
		Check Unique Id
	*/
	
	$servername = "localhost";
	$username = "w3_depet";
	$password = "4RLpRUzv";
	$dbname = "w3_depet";

	$connection = mysqli_connect($servername, $username, $password, $dbname);
	if (!$connection) {
		die("Could not connect: " . mysqli_error($connection));
	}

	/*the uniqueId cookie or session have never been set before or expired*/
	session_start();
	if ( !isset($_SESSION['CREATED'])) {
		session_unset();
   		session_destroy();
		echo "se_unset";
	}
	else if ( time() - $_SESSION['CREATED'] > 1800 ){
		session_unset();
                session_destroy();
		echo "se_unset";
	}
	else if ( !isset($_GET['uniqueId']) ){
		echo "id_unset";
	}
	else if ( $_SESSION['nickname'] != $_GET['uniqueId'] ){
		echo "id_noeql";
	}
	else{

	/* update current session status */
	session_regenerate_id(true);
        $_SESSION['CREATED'] = time(); 

	/* Get the user's version. */
	  $sql = "select max(version) as version from users where uniqid = '" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "'";
	  $result = mysqli_query($connection, $sql);
	  $row = mysqli_fetch_array($result);
	  $version = $row["version"];

	  $sql = "select * from users where uniqid = '" . mysqli_real_escape_string($connection, $_GET['uniqueId']) . "' and version = " . $version;
	  $result = mysqli_query($connection, $sql);
	  $row = mysqli_fetch_array($result);

	  echo json_encode($row);
	  mysqli_free_result($result);
	}

	mysqli_close($connection);

?>
